const http = require("http");
const fs = require("fs");
const path = require("path");
const crypto = require("crypto");

const root = __dirname;
const publicDir = path.join(root, "public");
const dataDir = path.join(root, "data");
const uploadDir = path.join(root, "uploads");
const dbPath = path.join(dataDir, "app-data.json");
const oldClientsPath = path.join(dataDir, "clients.json");
const port = Number(process.env.PORT || 4174);
const appUrl = process.env.APP_URL || `http://localhost:${port}`;
const isProduction = process.env.NODE_ENV === "production";

fs.mkdirSync(dataDir, { recursive: true });
fs.mkdirSync(uploadDir, { recursive: true });

let pgPool = null;
let mailer = null;
let s3Client = null;

const weeks = [
  "Finding your motivation",
  "Overcoming obstacles",
  "Discovering strengths",
  "Getting to know employers",
  "CVs and applications",
  "Interviews and ready for work",
];

const scoreAreas = [
  "Confidence and motivation",
  "Skills and experience",
  "Job search",
  "Job application",
];

function optionalRequire(name) {
  try {
    return require(name);
  } catch {
    return null;
  }
}

function hashPassword(password, salt = crypto.randomBytes(16).toString("hex")) {
  const hash = crypto.pbkdf2Sync(password, salt, 120000, 32, "sha256").toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password, saved) {
  if (!saved || !saved.includes(":")) return false;
  const [salt, hash] = saved.split(":");
  return crypto.timingSafeEqual(
    Buffer.from(hashPassword(password, salt).split(":")[1], "hex"),
    Buffer.from(hash, "hex"),
  );
}

function blankProgress() {
  return {
    scores: Object.fromEntries(scoreAreas.map(area => [area, Array(6).fill("")])),
    weeks: weeks.map(() => ({
      done: false,
      note: "",
      madGoal: "",
      deadline: "",
      motivating: false,
      achievable: false,
      hasDeadline: false,
    })),
    cvUploads: [],
  };
}

function initialData() {
  const clients = fs.existsSync(oldClientsPath) ? JSON.parse(fs.readFileSync(oldClientsPath, "utf8") || "[]") : [];
  return {
    users: [
      {
        id: crypto.randomUUID(),
        role: "admin",
        firstName: "Job Club",
        lastName: "Admin",
        email: process.env.ADMIN_EMAIL || "admin@jobclub.local",
        passwordHash: hashPassword(process.env.ADMIN_PASSWORD || "ChangeMe123!"),
        createdAt: new Date().toISOString(),
      },
    ],
    clients: clients.map(client => ({
      ...blankProgress(),
      ...client,
      userId: client.userId || null,
      messages: client.messages || [],
    })),
    announcements: [],
    outbox: [],
    sessions: {},
  };
}

async function initStorage() {
  if (process.env.DATABASE_URL) {
    const pg = optionalRequire("pg");
    if (!pg) throw new Error("The pg package is missing. Run npm install before hosting.");
    pgPool = new pg.Pool({
      connectionString: process.env.DATABASE_URL,
      ssl: process.env.PGSSLMODE === "disable" ? false : { rejectUnauthorized: false },
    });
    await pgPool.query("CREATE TABLE IF NOT EXISTS app_state (key text PRIMARY KEY, value jsonb NOT NULL, updated_at timestamptz NOT NULL DEFAULT now())");
    const existing = await pgPool.query("SELECT value FROM app_state WHERE key = $1", ["main"]);
    if (!existing.rowCount) {
      await pgPool.query("INSERT INTO app_state (key, value) VALUES ($1, $2)", ["main", initialData()]);
    }
    return;
  }
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, `${JSON.stringify(initialData(), null, 2)}\n`, "utf8");
  }
}

const storageReady = initStorage();

async function readData() {
  await storageReady;
  if (pgPool) {
    const result = await pgPool.query("SELECT value FROM app_state WHERE key = $1", ["main"]);
    return result.rows[0].value;
  }
  return JSON.parse(fs.readFileSync(dbPath, "utf8") || "{}");
}

async function writeData(data) {
  await storageReady;
  if (pgPool) {
    await pgPool.query("UPDATE app_state SET value = $2, updated_at = now() WHERE key = $1", ["main", data]);
    return;
  }
  fs.writeFileSync(dbPath, `${JSON.stringify(data, null, 2)}\n`, "utf8");
}

function send(res, status, body, type = "application/json; charset=utf-8") {
  res.writeHead(status, {
    "Content-Type": type,
    "X-Content-Type-Options": "nosniff",
    "Referrer-Policy": "same-origin",
  });
  res.end(body);
}

function json(res, status, body) {
  send(res, status, JSON.stringify(body));
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const chunks = [];
    req.on("data", chunk => chunks.push(chunk));
    req.on("end", () => resolve(Buffer.concat(chunks)));
    req.on("error", reject);
  });
}

async function readJson(req) {
  const body = await readBody(req);
  return JSON.parse(body.toString("utf8") || "{}");
}

function cookie(req, name) {
  const source = req.headers.cookie || "";
  const item = source.split(";").map(part => part.trim()).find(part => part.startsWith(`${name}=`));
  return item ? decodeURIComponent(item.slice(name.length + 1)) : "";
}

function publicUser(user) {
  if (!user) return null;
  const { passwordHash, resetTokenHash, ...safe } = user;
  return safe;
}

function currentUser(req, data) {
  const token = cookie(req, "jobclub_session");
  const session = token && data.sessions[token];
  if (!session) return null;
  return data.users.find(user => user.id === session.userId) || null;
}

function requireUser(req, res, data) {
  const user = currentUser(req, data);
  if (!user) json(res, 401, { error: "Please log in" });
  return user;
}

function requireAdmin(req, res, data) {
  const user = requireUser(req, res, data);
  if (user && user.role !== "admin") {
    json(res, 403, { error: "Admin only" });
    return null;
  }
  return user;
}

function cleanFileName(name) {
  return String(name || "cv-upload")
    .replace(/[/\\?%*:|"<>]/g, "-")
    .replace(/\s+/g, " ")
    .trim()
    .slice(0, 120) || "cv-upload";
}

function parseMultipart(buffer, contentType) {
  const boundaryMatch = /boundary=(?:"([^"]+)"|([^;]+))/i.exec(contentType || "");
  if (!boundaryMatch) return { fields: {}, files: {} };
  const boundary = `--${boundaryMatch[1] || boundaryMatch[2]}`;
  const parts = buffer.toString("binary").split(boundary).slice(1, -1);
  const fields = {};
  const files = {};

  for (const raw of parts) {
    const part = raw.replace(/^\r\n/, "").replace(/\r\n$/, "");
    const splitAt = part.indexOf("\r\n\r\n");
    if (splitAt === -1) continue;
    const headers = part.slice(0, splitAt);
    const bodyBinary = part.slice(splitAt + 4);
    const disposition = /content-disposition: form-data;([^\r\n]+)/i.exec(headers);
    if (!disposition) continue;
    const name = /name="([^"]+)"/i.exec(disposition[1]);
    const filename = /filename="([^"]*)"/i.exec(disposition[1]);
    if (!name) continue;

    if (filename && filename[1]) {
      files[name[1]] = { filename: filename[1], buffer: Buffer.from(bodyBinary, "binary") };
    } else {
      fields[name[1]] = Buffer.from(bodyBinary, "binary").toString("utf8");
    }
  }
  return { fields, files };
}

function clientForUser(data, user) {
  return data.clients.find(client => client.userId === user.id || client.email?.toLowerCase() === user.email.toLowerCase());
}

function routeStatic(req, res) {
  const mime = {
    ".html": "text/html; charset=utf-8",
    ".css": "text/css; charset=utf-8",
    ".js": "application/javascript; charset=utf-8",
    ".json": "application/json; charset=utf-8",
  };
  const requestPath = decodeURIComponent(new URL(req.url, appUrl).pathname);
  const safePath = requestPath === "/" ? "/index.html" : requestPath;
  const filePath = path.normalize(path.join(publicDir, safePath));
  if (!filePath.startsWith(publicDir) || !fs.existsSync(filePath) || fs.statSync(filePath).isDirectory()) {
    return send(res, 404, "Not found", "text/plain");
  }
  res.writeHead(200, {
    "Content-Type": mime[path.extname(filePath)] || "application/octet-stream",
    "X-Content-Type-Options": "nosniff",
  });
  fs.createReadStream(filePath).pipe(res);
}

function emailTransport() {
  if (!process.env.SMTP_HOST) return null;
  if (!mailer) {
    const nodemailer = optionalRequire("nodemailer");
    if (!nodemailer) throw new Error("The nodemailer package is missing. Run npm install before sending email.");
    mailer = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: Number(process.env.SMTP_PORT || 587),
      secure: process.env.SMTP_SECURE === "true",
      auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
    });
  }
  return mailer;
}

async function sendEmail(to, subject, body) {
  const transport = emailTransport();
  if (!transport) return { sent: false, note: "Email settings not configured" };
  await transport.sendMail({
    from: process.env.EMAIL_FROM || process.env.SMTP_USER,
    to,
    subject,
    text: `${body}\n\nLog in: ${appUrl}`,
  });
  return { sent: true };
}

async function addOutbox(data, recipients, subject, body, kind = "message") {
  const now = new Date().toISOString();
  for (const recipient of recipients) {
    const item = {
      id: crypto.randomUUID(),
      kind,
      to: recipient.email,
      name: [recipient.firstName, recipient.lastName].filter(Boolean).join(" "),
      subject,
      body,
      createdAt: now,
      sent: false,
    };
    try {
      const result = await sendEmail(recipient.email, subject, body);
      item.sent = result.sent;
      item.note = result.note || "";
    } catch (error) {
      item.error = error.message;
    }
    data.outbox.unshift(item);
  }
}

async function saveUploadedFile(savedName, upload) {
  if (process.env.S3_BUCKET) {
    if (!s3Client) {
      const aws = optionalRequire("@aws-sdk/client-s3");
      if (!aws) throw new Error("The @aws-sdk/client-s3 package is missing. Run npm install before using S3 uploads.");
      s3Client = {
        client: new aws.S3Client({
          region: process.env.S3_REGION || "auto",
          endpoint: process.env.S3_ENDPOINT || undefined,
          forcePathStyle: process.env.S3_FORCE_PATH_STYLE === "true",
          credentials: process.env.S3_ACCESS_KEY_ID ? {
            accessKeyId: process.env.S3_ACCESS_KEY_ID,
            secretAccessKey: process.env.S3_SECRET_ACCESS_KEY,
          } : undefined,
        }),
        PutObjectCommand: aws.PutObjectCommand,
      };
    }
    await s3Client.client.send(new s3Client.PutObjectCommand({
      Bucket: process.env.S3_BUCKET,
      Key: savedName,
      Body: upload.buffer,
      ContentType: "application/octet-stream",
      ServerSideEncryption: process.env.S3_SERVER_SIDE_ENCRYPTION || undefined,
    }));
    return { storage: "s3", key: savedName };
  }
  fs.writeFileSync(path.join(uploadDir, savedName), upload.buffer);
  return { storage: "local", key: savedName };
}

function tempPassword() {
  return crypto.randomBytes(9).toString("base64url");
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, appUrl);
    const data = await readData();

    if (url.pathname === "/api/health" && req.method === "GET") {
      return json(res, 200, { ok: true, storage: pgPool ? "postgres" : "local" });
    }

    if (url.pathname === "/api/session" && req.method === "GET") {
      return json(res, 200, { user: publicUser(currentUser(req, data)), appUrl });
    }

    if (url.pathname === "/api/login" && req.method === "POST") {
      const input = await readJson(req);
      const user = data.users.find(item => item.email.toLowerCase() === String(input.email || "").toLowerCase());
      if (!user || !verifyPassword(input.password || "", user.passwordHash)) return json(res, 401, { error: "Wrong email or password" });
      const token = crypto.randomBytes(24).toString("hex");
      data.sessions[token] = { userId: user.id, createdAt: new Date().toISOString() };
      await writeData(data);
      res.writeHead(200, {
        "Content-Type": "application/json; charset=utf-8",
        "Set-Cookie": `jobclub_session=${token}; HttpOnly; SameSite=Lax; Path=/${isProduction ? "; Secure" : ""}`,
      });
      return res.end(JSON.stringify({ user: publicUser(user) }));
    }

    if (url.pathname === "/api/logout" && req.method === "POST") {
      const token = cookie(req, "jobclub_session");
      delete data.sessions[token];
      await writeData(data);
      res.writeHead(200, {
        "Content-Type": "application/json; charset=utf-8",
        "Set-Cookie": "jobclub_session=; Max-Age=0; Path=/",
      });
      return res.end(JSON.stringify({ ok: true }));
    }

    if (url.pathname === "/api/register" && req.method === "POST") {
      const input = await readJson(req);
      const email = String(input.email || "").trim().toLowerCase();
      if (!input.privacyAccepted) return json(res, 400, { error: "Please accept the privacy statement" });
      if (!email || !input.password) return json(res, 400, { error: "Email and password are needed" });
      if (String(input.password).length < 8) return json(res, 400, { error: "Password must be at least 8 characters" });
      if (data.users.some(user => user.email.toLowerCase() === email)) return json(res, 400, { error: "Email already has an account" });
      const user = {
        id: crypto.randomUUID(),
        role: "member",
        firstName: input.firstName || "",
        lastName: input.lastName || "",
        email,
        passwordHash: hashPassword(input.password),
        privacyAcceptedAt: new Date().toISOString(),
        createdAt: new Date().toISOString(),
      };
      const client = {
        ...blankProgress(),
        id: crypto.randomUUID(),
        userId: user.id,
        firstName: user.firstName,
        lastName: user.lastName,
        email,
        phone: input.phone || "",
        date: new Date().toISOString().slice(0, 10),
        messages: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      data.users.push(user);
      data.clients.unshift(client);
      await writeData(data);
      return json(res, 200, { user: publicUser(user) });
    }

    if (url.pathname === "/api/change-password" && req.method === "POST") {
      const user = requireUser(req, res, data);
      if (!user) return;
      const input = await readJson(req);
      if (!verifyPassword(input.currentPassword || "", user.passwordHash)) return json(res, 400, { error: "Current password is wrong" });
      if (String(input.newPassword || "").length < 8) return json(res, 400, { error: "New password must be at least 8 characters" });
      user.passwordHash = hashPassword(input.newPassword);
      await writeData(data);
      return json(res, 200, { ok: true });
    }

    if (url.pathname === "/api/admin/clients" && req.method === "GET") {
      if (!requireAdmin(req, res, data)) return;
      return json(res, 200, data.clients);
    }

    if (url.pathname === "/api/admin/clients" && req.method === "POST") {
      if (!requireAdmin(req, res, data)) return;
      const incoming = await readJson(req);
      const now = new Date().toISOString();
      const client = { ...blankProgress(), ...incoming, id: incoming.id || crypto.randomUUID(), updatedAt: now, createdAt: incoming.createdAt || now };
      const index = data.clients.findIndex(item => item.id === client.id);
      if (index >= 0) data.clients[index] = client;
      else data.clients.unshift(client);
      await writeData(data);
      return json(res, 200, client);
    }

    if (url.pathname.startsWith("/api/admin/clients/") && req.method === "DELETE") {
      if (!requireAdmin(req, res, data)) return;
      const id = url.pathname.split("/").pop();
      data.clients = data.clients.filter(client => client.id !== id);
      await writeData(data);
      return json(res, 200, { ok: true });
    }

    if (url.pathname === "/api/admin/reset-password" && req.method === "POST") {
      if (!requireAdmin(req, res, data)) return;
      const input = await readJson(req);
      const client = data.clients.find(item => item.id === input.clientId);
      const member = client && data.users.find(item => item.id === client.userId);
      if (!member) return json(res, 404, { error: "Member account not found for this client" });
      const password = tempPassword();
      member.passwordHash = hashPassword(password);
      await addOutbox(data, [client], "Your Job Club password has been reset", `Your temporary password is: ${password}\nPlease log in and change it straight away.`, "password");
      await writeData(data);
      return json(res, 200, { password });
    }

    if (url.pathname === "/api/member/me" && req.method === "GET") {
      const user = requireUser(req, res, data);
      if (!user) return;
      const client = clientForUser(data, user);
      return json(res, 200, { user: publicUser(user), client, announcements: data.announcements });
    }

    if (url.pathname === "/api/member/me" && req.method === "POST") {
      const user = requireUser(req, res, data);
      if (!user) return;
      const input = await readJson(req);
      const client = clientForUser(data, user);
      if (!client) return json(res, 404, { error: "Client record not found" });
      const allowed = ["phone", "address", "postcode", "employmentStatus", "reasons", "notes", "scores", "weeks"];
      allowed.forEach(key => {
        if (Object.hasOwn(input, key)) client[key] = input[key];
      });
      client.updatedAt = new Date().toISOString();
      await writeData(data);
      return json(res, 200, client);
    }

    if (url.pathname === "/api/announcements" && req.method === "POST") {
      if (!requireAdmin(req, res, data)) return;
      const input = await readJson(req);
      const announcement = {
        id: crypto.randomUUID(),
        title: input.title || "Announcement",
        body: input.body || "",
        createdAt: new Date().toISOString(),
      };
      data.announcements.unshift(announcement);
      await addOutbox(data, data.clients.filter(client => client.email), announcement.title, announcement.body, "announcement");
      await writeData(data);
      return json(res, 200, announcement);
    }

    if (url.pathname === "/api/messages" && req.method === "POST") {
      if (!requireAdmin(req, res, data)) return;
      const input = await readJson(req);
      const recipients = input.clientId === "all" ? data.clients : data.clients.filter(client => client.id === input.clientId);
      const now = new Date().toISOString();
      recipients.forEach(client => {
        client.messages = client.messages || [];
        client.messages.unshift({ id: crypto.randomUUID(), subject: input.subject || "Message from Job Club", body: input.body || "", createdAt: now });
      });
      await addOutbox(data, recipients.filter(client => client.email), input.subject || "Message from Job Club", input.body || "", "message");
      await writeData(data);
      return json(res, 200, { ok: true });
    }

    if (url.pathname === "/api/weekly-update" && req.method === "POST") {
      if (!requireAdmin(req, res, data)) return;
      const input = await readJson(req);
      const weekNumber = Number(input.weekNumber || 1);
      const subject = `Job Club week ${weekNumber} update`;
      const body = input.body || `This week is ${weeks[weekNumber - 1] || "your next Job Club session"}. Please log in, update your goal scores, and add your weekly goal.`;
      await addOutbox(data, data.clients.filter(client => client.email), subject, body, "weekly");
      await writeData(data);
      return json(res, 200, { ok: true });
    }

    if (url.pathname === "/api/outbox" && req.method === "GET") {
      if (!requireAdmin(req, res, data)) return;
      return json(res, 200, data.outbox);
    }

    if (url.pathname === "/api/upload" && req.method === "POST") {
      const user = requireUser(req, res, data);
      if (!user) return;
      const body = await readBody(req);
      const { fields, files } = parseMultipart(body, req.headers["content-type"]);
      const upload = files.cv;
      if (!upload) return json(res, 400, { error: "No CV file received" });
      if (upload.buffer.length > Number(process.env.MAX_UPLOAD_BYTES || 10 * 1024 * 1024)) return json(res, 400, { error: "CV file is too large" });
      const client = user.role === "admin"
        ? data.clients.find(item => item.id === fields.clientId)
        : clientForUser(data, user);
      if (!client) return json(res, 404, { error: "Client not found" });
      const originalName = cleanFileName(upload.filename);
      const savedName = `${client.id}/${Date.now()}-${crypto.randomBytes(4).toString("hex")}-${originalName}`;
      const stored = await saveUploadedFile(savedName, upload);
      const record = { name: originalName, savedName, size: upload.buffer.length, uploadedAt: new Date().toISOString(), ...stored };
      client.cvUploads = client.cvUploads || [];
      client.cvUploads.unshift(record);
      client.updatedAt = new Date().toISOString();
      await writeData(data);
      return json(res, 200, record);
    }

    return routeStatic(req, res);
  } catch (error) {
    json(res, 500, { error: error.message });
  }
});

server.listen(port, () => {
  console.log(`Job Club app running at ${appUrl}`);
  console.log(`Storage: ${process.env.DATABASE_URL ? "PostgreSQL" : "local file"}`);
});
