@echo off
cd /d "%~dp0"
start "" "http://localhost:4174"
"C:\Users\antho\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe" server.js
